//
//  Travori Custom JavaScript
//  This script handles custom functionality, such as modal content loading, cookie consent, and form submission.
//

// Simple log to confirm script is connected
console.log("Travori: script.js is loaded.");

// --- Cookie Consent Banner Logic ---
function handleCookieConsent() {
  const consentBanner = document.getElementById("cookie-banner");
  if (!consentBanner) return; // Exit if the banner element doesn't exist on the page
  const acceptButton = document.getElementById("accept-cookies");
  const consentGiven = localStorage.getItem("cookieConsent");

  // Show the banner if consent has not been given
  if (!consentGiven) {
    consentBanner.style.display = "block";
  }

  // Handle the button click
  acceptButton.addEventListener("click", () => {
    localStorage.setItem("cookieConsent", "true");
    consentBanner.style.display = "none";
    console.log("Cookie consent accepted.");
  });
}

// --- Contact Form Submission Logic (New) ---
function handleContactFormSubmission() {
  const contactForm = document.getElementById("contactForm");
  if (!contactForm) return; // Exit if the form element doesn't exist on the page

  contactForm.addEventListener("submit", function (event) {
    // Prevent the default form submission to avoid a page reload
    event.preventDefault();

    // Perform basic form validation (optional, but good practice)
    if (contactForm.checkValidity()) {
      console.log("Form is valid. Submitting...");

      // In a real-world scenario, you would send the data to a server here.
      // For this static site, we will just show the success modal.

      // Get the modal instance and show it
      const successModal = new bootstrap.Modal(
        document.getElementById("successModal")
      );
      successModal.show();

      // Reset the form after a successful submission
      contactForm.reset();
    } else {
      console.log(
        "Form validation failed. Please fill out all required fields."
      );
    }
  });
}

// --- Destination Modal Functionality (as before) ---
// Function to handle the opening of a specific destination modal
function openDestinationModal(destinationId) {
  const destinationData = {
    // ... (your existing destinationData object)
    kyoto: {
      title: "Kyoto, Japan: A Journey Through Time",
      intro:
        "Kyoto offers a timeless escape into Japan's rich history and culture. Known for its classical Buddhist temples, serene gardens, and geishas, it is a city where ancient traditions thrive alongside modern life.",
      sights: [
        "Fushimi Inari-taisha: The iconic shrine with thousands of red torii gates.",
        "Kinkaku-ji (Golden Pavilion): A stunning Zen temple covered in gold leaf.",
        "Arashiyama Bamboo Grove: A breathtaking, mystical bamboo forest.",
        "Gion District: Kyoto's famous geisha district, perfect for an evening stroll.",
      ],
      tips: [
        "Best Time to Visit: Spring (March-May) for cherry blossoms or Autumn (Sept-Nov) for fall foliage.",
        "What to Pack: Comfortable shoes for walking, and layers for changing weather.",
        "Local Etiquette: Bowing is a sign of respect, and remember to remove your shoes when entering homes, temples, and some restaurants.",
      ],
    },
    "machu-picchu": {
      title: "Machu Picchu, Peru: The Lost City of the Incas",
      intro:
        "Machu Picchu is a 15th-century Inca citadel nestled high in the Andes Mountains. Its incredible stonework and dramatic mountain setting make it one of the most remarkable archaeological sites in the world.",
      sights: [
        "The Sun Gate (Inti Punku): The traditional entry point for trekkers on the Inca Trail, offering a magnificent first view of the site.",
        "Temple of the Sun: A curved structure built with incredible precision.",
        "Huayna Picchu: The towering mountain that provides the classic backdrop for the citadel.",
        "Intihuatana Stone: An ancient ritual stone believed to be an astronomical clock or calendar.",
      ],
      tips: [
        "Best Time to Visit: The dry season from May to October, especially June-August.",
        "What to Pack: Sunscreen, a hat, a waterproof jacket, and plenty of water.",
        "Practical Tips: Book your entry tickets and train/bus tickets well in advance, as they sell out quickly.",
      ],
    },
    serengeti: {
      title: "Serengeti, Tanzania: The Great Migration",
      intro:
        "The Serengeti is a vast ecosystem in eastern Africa known for its incredible biodiversity and the annual migration of millions of wildebeest, zebras, and other animals in search of fresh grazing.",
      sights: [
        "Serengeti National Park: The main stage for the Great Migration.",
        "Ngorongoro Crater: A massive, deep volcanic caldera with one of the densest populations of wildlife.",
        "Lake Manyara National Park: Famous for its tree-climbing lions and flamingoes.",
        "Olduvai Gorge: A paleoanthropological site, providing evidence of early human ancestors.",
      ],
      tips: [
        "Best Time to Visit: February-March for the wildebeest calving season, or June-September for the migration river crossings.",
        "What to Pack: Neutral-colored clothing, a wide-brimmed hat, insect repellent, and a good camera with a telephoto lens.",
        "Practical Tips: A guided safari is essential. Choose a reputable tour operator who practices sustainable tourism.",
      ],
    },
    "amalfi-coast": {
      title: "Amalfi Coast, Italy: La Dolce Vita",
      intro:
        "The Amalfi Coast is a stunning stretch of coastline on the Sorrentine Peninsula. With its dramatic cliffs, colorful villages clinging to the hillsides, and sparkling azure waters, it’s the epitome of coastal charm.",
      sights: [
        "Positano: The most famous village, known for its iconic pastel-colored houses.",
        "Amalfi: The historic center of the coast, with a beautiful cathedral.",
        "Ravello: Perched high above the sea, offering breathtaking panoramic views from its gardens.",
        "Capri Island: Easily accessible by ferry, with its stunning Blue Grotto sea cave.",
      ],
      tips: [
        "Best Time to Visit: Late Spring (May-June) and early Autumn (Sept-Oct) to avoid the peak summer crowds and heat.",
        "What to Pack: Comfortable sandals or shoes for walking up and down steep streets, and a light jacket for evenings.",
        "Practical Tips: Use the local SITA bus or ferries to travel between towns instead of driving, as roads are narrow and parking is limited.",
      ],
    },
    banff: {
      title: "Banff National Park, Canada: The Canadian Rockies",
      intro:
        "Banff National Park is a breathtaking wilderness of soaring mountains, turquoise lakes, and vast forests. A UNESCO World Heritage Site, it offers endless opportunities for hiking, wildlife spotting, and adventure.",
      sights: [
        "Lake Louise: Famous for its stunning turquoise water and the Victoria Glacier backdrop.",
        "Moraine Lake: A glacial lake with an unforgettable vibrant blue hue.",
        "Sulphur Mountain: Take the Banff Gondola to the summit for panoramic views of the entire valley.",
        "Johnston Canyon: A scenic hike along catwalks through a stunning canyon to waterfalls.",
      ],
      tips: [
        "Best Time to Visit: June to August for warm weather and hiking, or December to February for winter sports.",
        "What to Pack: Layers, a waterproof jacket, bear spray for hiking in remote areas, and sturdy hiking boots.",
        "Practical Tips: Park passes are required for entry. Visit popular spots like Lake Louise early in the morning to find parking.",
      ],
    },
    iceland: {
      title: "Iceland's Golden Circle: Fire and Ice",
      intro:
        "The Golden Circle is a popular tourist route in southern Iceland, covering about 300 kilometers from Reykjavík and back. It showcases three of Iceland's most spectacular natural attractions.",
      sights: [
        "Þingvellir National Park: A site of historical importance and geological wonder, where the North American and Eurasian tectonic plates meet.",
        "Gullfoss Waterfall: A powerful and majestic two-tiered waterfall, often seen with a rainbow in its spray.",
        "Geysir Geothermal Area: Home to the Strokkur geyser, which erupts every 5-10 minutes.",
        "Kerið Crater Lake: A beautiful volcanic crater lake with strikingly red walls.",
      ],
      tips: [
        "Best Time to Visit: Summer (June-August) for long daylight hours and easy travel. Winter (Sept-March) for a chance to see the Northern Lights.",
        "What to Pack: Layered clothing is essential due to unpredictable weather, and waterproof outerwear is a must.",
        "Practical Tips: Renting a car is the best way to see the Golden Circle at your own pace. Be prepared for all weather conditions, even in summer.",
      ],
    },
    "cape-town": {
      title: "Cape Town, South Africa: Where Oceans Meet Mountains",
      intro:
        "Cape Town is a vibrant coastal city nestled between the Atlantic Ocean and Table Mountain. Known for its stunning landscapes, rich history, and diverse culture, it’s a gateway to unforgettable African adventures.",
      sights: [
        "Table Mountain: Take a cable car or hike to the top for panoramic city views.",
        "Robben Island: The former prison where Nelson Mandela was held, now a powerful museum.",
        "Boulders Beach: Home to a colony of charming African penguins.",
        "Cape of Good Hope: A dramatic rocky headland with stunning ocean views.",
      ],
      tips: [
        "Best Time to Visit: October to April for the best weather.",
        "What to Pack: Sunscreen, a windbreaker for mountain hikes, and comfortable walking shoes.",
        "Practical Tips: Book Table Mountain tickets in advance and arrive early to avoid crowds.",
      ],
    },
    petra: {
      title: "Petra, Jordan: The Rose-Red City",
      intro:
        "Carved into rose-colored cliffs, Petra is an archaeological wonder and one of the New Seven Wonders of the World. Once a thriving trading hub, it’s now a symbol of Jordan’s ancient heritage.",
      sights: [
        "The Treasury (Al-Khazneh): The most iconic facade of Petra, best seen at dawn or dusk.",
        "The Monastery (Ad Deir): A monumental structure reached via a scenic uphill climb.",
        "Siq: A narrow canyon that serves as the dramatic entrance to the ancient city.",
        "Royal Tombs: Impressive burial sites carved into the rock face.",
      ],
      tips: [
        "Best Time to Visit: Spring (March-May) or Autumn (Sept-Nov) for cooler temperatures.",
        "What to Pack: A hat, sunscreen, plenty of water, and sturdy walking shoes.",
        "Practical Tips: Arrive early to explore before tour groups, and consider a night visit to see Petra by candlelight.",
      ],
    },
    queenstown: {
      title: "Queenstown, New Zealand: Adventure Capital of the World",
      intro:
        "Nestled on the shores of Lake Wakatipu, Queenstown is a paradise for thrill-seekers and nature lovers alike. Surrounded by the Southern Alps, it offers year-round adventure and breathtaking scenery.",
      sights: [
        "Skyline Gondola: Ride to Bob’s Peak for panoramic views and fun activities.",
        "Shotover Jet: A high-speed boat ride through narrow canyons.",
        "Milford Sound: A stunning fjord accessible via day trips or scenic flights.",
        "Arrowtown: A charming historic gold mining village nearby.",
      ],
      tips: [
        "Best Time to Visit: December to February for summer activities; June to August for skiing.",
        "What to Pack: Outdoor gear, layered clothing, and waterproof jackets.",
        "Practical Tips: Book adventure activities in advance, especially in peak season.",
      ],
    },
    istanbul: {
      title: "Istanbul, Turkey: Where East Meets West",
      intro:
        "Spanning two continents, Istanbul is a city steeped in history and culture. Its unique blend of European and Asian influences creates a rich tapestry of architecture, cuisine, and tradition.",
      sights: [
        "Hagia Sophia: A majestic structure with a layered history as a church and mosque.",
        "Blue Mosque: Famous for its blue tiles and impressive domes.",
        "Grand Bazaar: One of the oldest and largest covered markets in the world.",
        "Bosphorus Cruise: See the city’s skyline from the water, passing palaces and bridges.",
      ],
      tips: [
        "Best Time to Visit: April to June and September to November for pleasant weather.",
        "What to Pack: Modest clothing for visiting mosques and a good travel guide.",
        "Practical Tips: Use a local Istanbulkart for public transport and avoid taxis during peak traffic.",
      ],
    },
    "new-york": {
      title: "New York City, USA: The City That Never Sleeps",
      intro:
        "New York City is a global hub for culture, finance, and entertainment. From its iconic skyline to its vibrant neighborhoods, it offers something for every traveler, day or night.",
      sights: [
        "Statue of Liberty: A symbol of freedom and an essential visit.",
        "Central Park: A green oasis in the heart of Manhattan.",
        "Empire State Building: For stunning views of the city.",
        "Broadway: Catch a world-class show in the Theater District.",
      ],
      tips: [
        "Best Time to Visit: Spring (April–June) and Fall (Sept–Nov) for mild weather.",
        "What to Pack: Comfortable walking shoes and layers for unpredictable weather.",
        "Practical Tips: Use the subway to avoid traffic, and book attractions in advance online.",
      ],
    },

    santorini: {
      title: "Santorini, Greece: Sunset Over the Aegean",
      intro:
        "Santorini is a postcard-perfect island in the Aegean Sea, known for its white-washed buildings, blue domes, and breathtaking sunsets. It’s a romantic and idyllic getaway steeped in history.",
      sights: [
        "Oia: The most famous village for sunset views and stunning architecture.",
        "Fira: The bustling capital with shops, museums, and vibrant nightlife.",
        "Red Beach: A striking beach with red volcanic sand.",
        "Ancient Akrotiri: A well-preserved Minoan Bronze Age settlement.",
      ],
      tips: [
        "Best Time to Visit: Late April to early November, with May-June or Sept being ideal.",
        "What to Pack: Sunglasses, swimwear, light clothing, and comfortable sandals.",
        "Practical Tips: Stay in Oia or Imerovigli for the best views, and book ferries or flights early in peak season.",
      ],
    },
  };

  const data = destinationData[destinationId];
  if (data) {
    // Update modal title
    document.getElementById("modalTitle").innerText = data.title;

    // Update modal introduction
    document.getElementById("modalIntro").innerText = data.intro;

    // Update Must-See Sights list
    const sightsList = document.getElementById("sightsList");
    sightsList.innerHTML = ""; // Clear previous list
    data.sights.forEach((sight) => {
      const li = document.createElement("li");
      li.innerText = sight;
      sightsList.appendChild(li);
    });

    // Update Practical Tips list
    const tipsList = document.getElementById("tipsList");
    tipsList.innerHTML = ""; // Clear previous list
    data.tips.forEach((tip) => {
      const li = document.createElement("li");
      li.innerText = tip;
      tipsList.appendChild(li);
    });

    // Show the modal
    const myModal = new bootstrap.Modal(
      document.getElementById("destinationModal")
    );
    myModal.show();
  }
}

// Ensure the new functions are called when the page is loaded
document.addEventListener("DOMContentLoaded", () => {
  handleCookieConsent();
  handleContactFormSubmission();
});


document.addEventListener("DOMContentLoaded", () => {
    const banner = document.getElementById("cookie-consent-banner");
    const acceptBtn = document.getElementById("accept-cookies-btn");

    // Check if cookies already accepted
    if (localStorage.getItem("cookiesAccepted")) {
        banner.style.display = "none";
    } else {
        banner.style.display = "block";
    }

    // Accept button handler
    acceptBtn.addEventListener("click", () => {
        localStorage.setItem("cookiesAccepted", "true"); // Save user choice
        banner.style.display = "none";
    });
});

document.cookie = "cookiesAccepted=true; path=/; max-age=" + 60*60*24*365; 
