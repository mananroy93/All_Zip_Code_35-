// This file stores all the blog post data as an array of objects.
// Each object contains all the information needed to display an article.

const blogPosts = [
  {
    id: 1,
    title: "The Rise of AI in Healthcare",
    category: "Technology",
    image: "../images/1img.jpg",
    summary:
      "How machine learning is revolutionizing diagnostics and patient care.",
    fullContent:
      "The integration of artificial intelligence into healthcare is transforming patient care. AI algorithms can analyze medical images, predict disease outbreaks, and assist in personalized treatment plans. This shift promises to improve accuracy and efficiency, but it also raises important questions about data privacy and the role of human expertise.",
    keyTakeaways: [
      "AI algorithms are being used for diagnostics and treatment planning.",
      "Machine learning can predict disease outbreaks with high accuracy.",
      "Ethical challenges include data privacy and clinical liability.",
    ],
    relatedLinks: [
      "The Future of AI in Medicine",
      "Ethical Considerations of AI in Healthcare",
      "Medical Imaging with Machine Learning",
    ],
  },
  {
    id: 2,
    title: "Future of Remote Work",
    category: "Business",
    image: "../images/2img.jpg",
    summary:
      "Examining the long-term impact of remote and hybrid work models on company culture.",
    fullContent:
      "The global shift to remote and hybrid work models has profound implications for the business world. This article explores how companies are adapting to these new structures, from implementing new collaboration tools to rethinking office spaces. The future of work is a blend of flexibility and innovation, with a focus on maintaining company culture in a decentralized environment.",
    keyTakeaways: [
      "Remote work is leading to a re-evaluation of corporate culture.",
      "Technology is enabling seamless collaboration across distances.",
      "Companies are exploring flexible work schedules and virtual-first policies.",
    ],
    relatedLinks: [
      "The Psychology of Remote Teams",
      "Top 10 Collaboration Tools for Distributed Teams",
      "Redefining Productivity in the Digital Age",
    ],
  },
  {
    id: 3,
    title: "Exploring Mars: The Next Chapter",
    category: "Science",
    image: "../images/3img.jpg",
    summary:
      "A detailed look at the latest rover missions and plans for human exploration.",
    fullContent:
      "Humanity's fascination with Mars continues to drive new missions. NASA's Perseverance rover is currently searching for signs of ancient microbial life, while other nations are planning their own ambitious robotic missions. The ultimate goal is to pave the way for a crewed mission to the red planet, a feat that would be a landmark achievement in human history.",
    keyTakeaways: [
      "New rovers are searching for signs of ancient life.",
      "International collaboration is key for future Mars missions.",
      "Long-term plans include a human colony on Mars.",
    ],
    relatedLinks: [
      "NASA's Mars Exploration Program",
      "The Challenges of Living on Mars",
      "Water on Mars: A New Discovery",
    ],
  },
  {
    id: 4,
    title: "Blockchain Beyond Crypto",
    category: "Technology",
    image: "../images/4img.jpg",
    summary:
      "How this technology is transforming supply chain management and data security.",
    fullContent:
      "While blockchain is most famous for powering cryptocurrencies like Bitcoin, its potential extends far beyond finance. This article dives into how decentralized ledger technology is being applied to supply chain management to improve transparency, enhance security, and reduce fraud. It also explores its applications in digital identity and voting systems.",
    keyTakeaways: [
      "Blockchain improves transparency and security in supply chains.",
      "The technology is being explored for digital identity and secure voting.",
      "Decentralization reduces the risk of a single point of failure.",
    ],
    relatedLinks: [
      "How Blockchain is Reshaping Supply Chains",
      "Decentralized Finance Explained",
      "The Future of Digital Identity",
    ],
  },
  {
    id: 5,
    title: "Gene Editing Breakthroughs",
    category: "Science",
    image: "../images/5img.jpg",
    summary:
      "An overview of the latest advancements in CRISPR technology and its ethical implications.",
    fullContent:
      "The groundbreaking gene-editing technology known as CRISPR is moving from the lab to the field, offering a powerful new tool for agriculture. By making precise changes to a plant's DNA, scientists can create crops that are more resilient to disease, require less water, and offer higher nutritional value.",
    keyTakeaways: [
      "CRISPR allows for precise and efficient gene editing in plants and animals.",
      "It is being used to develop crops resistant to drought, pests, and viruses.",
      "This technology can also enhance the nutritional content of staple crops.",
      "Ethical and regulatory debates surround the widespread use of gene-edited foods.",
    ],
    relatedLinks: [
      "What is CRISPR? A Simple Explanation",
      "The Future of Food Security",
      "The Global Debate on GMOs vs. Gene-Edited Crops",
    ],
  },
  {
    id: 6,
    title: "Quantum Computing Explained",
    category: "Technology",
    image: "../images/6img.jpg",
    summary:
      "A simple guide to a complex field and its potential to reshape the tech industry.",
    fullContent:
      "Quantum computing is a revolutionary technology that promises to solve problems that are currently impossible for classical computers. This article demystifies the core concepts of quantum mechanics, such as superposition and entanglement, and explores the potential impact of quantum computers on fields like cryptography, drug discovery, and materials science.",
    keyTakeaways: [
      "Quantum computers use qubits to perform complex calculations.",
      "It will have a massive impact on cryptography and data security.",
      "Major tech companies are in a race to build the first functional quantum computer.",
    ],
    relatedLinks: [
      "Quantum Entanglement Made Simple",
      "The Quantum Race: Who Will Win?",
      "How Quantum Computing Will Change the World",
    ],
  },
  {
    id: 7,
    title: "Navigating Post-Pandemic Economics",
    category: "Business",
    image: "../images/7img.jpg",
    summary:
      "How companies are adapting to new consumer behaviors and supply chain challenges.",
    fullContent:
      "The global economy has entered a new phase, shaped by the lasting effects of the pandemic. Businesses are re-evaluating their strategies to cope with shifting consumer habits, remote work models, and ongoing supply chain disruptions. This article explores how companies can adapt and thrive in this new environment.",
    keyTakeaways: [
      "Consumer spending has shifted from services to goods.",
      "Supply chains are becoming more localized and diversified.",
      "Companies are increasingly prioritizing digital transformation and e-commerce.",
    ],
    relatedLinks: [
      "The Impact of E-Commerce on Retail",
      "Building Resilient Supply Chains",
      "The Future of the Office Space",
    ],
  },
  {
    id: 8,
    title: "The Future of E-Commerce",
    category: "Business",
    image: "../images/8img.jpg",
    summary:
      "Examining the rise of live shopping and social commerce platforms.",
    fullContent:
      "E-commerce is no longer just about online stores. The industry is rapidly evolving with new interactive formats. Live shopping, where influencers showcase products in real-time, and social commerce, which integrates shopping directly into social media platforms, are leading the charge in creating more engaging and personalized shopping experiences.",
    keyTakeaways: [
      "Live shopping boosts consumer engagement and trust.",
      "Social commerce reduces friction by allowing in-app purchases.",
      "These new formats are particularly popular with Gen Z and millennials.",
    ],
    relatedLinks: [
      "Top 5 Social Commerce Platforms",
      "Building a Brand on TikTok",
      "The Rise of Direct-to-Consumer (D2C) Brands",
    ],
  },
  {
    id: 9,
    title: "Corporate Adoption of Crypto",
    category: "Business",
    image: "../images/9img.jpg",
    summary:
      "A look into which companies are adding cryptocurrency to their balance sheets.",
    fullContent:
      "While once a fringe asset, cryptocurrency is gaining mainstream acceptance as a growing number of publicly traded companies add Bitcoin and other digital assets to their balance sheets. This trend reflects a new perspective on crypto as a legitimate store of value and a hedge against inflation.",
    keyTakeaways: [
      "Companies are holding crypto to diversify their treasury assets.",
      "The move signals a growing belief in the long-term value of digital currencies.",
      "Regulatory uncertainty and volatility remain significant risks.",
    ],
    relatedLinks: [
      "Bitcoin vs. Ethereum: A Simple Comparison",
      "A Look at Corporate Crypto Holdings",
      "Regulatory Outlook for Digital Assets",
    ],
  },
];
