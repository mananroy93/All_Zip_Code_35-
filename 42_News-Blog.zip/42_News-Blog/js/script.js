// This file handles all the dynamic and interactive functionality for the website.
document.addEventListener("DOMContentLoaded", function () {
  // --- Cookie Consent Banner Functionality ---
  const cookieBanner = document.getElementById("cookieBanner");
  const acceptCookiesBtn = document.getElementById("acceptCookiesBtn");

  // Check if user has already accepted cookies
  const hasAcceptedCookies = localStorage.getItem("cookieAccepted");

  if (!hasAcceptedCookies) {
    // If not accepted, show the banner
    cookieBanner.style.display = "block";
  }

  // Handle the "Accept" button click
  acceptCookiesBtn.addEventListener("click", function () {
    // Set a flag in localStorage
    localStorage.setItem("cookieAccepted", "true");
    // Hide the banner
    cookieBanner.style.display = "none";
  });

  // --- Dynamic Content Loading for Blog Pages ---
  const blogGrid = document.getElementById("blog-grid");
  const blogContent = document.getElementById("blog-content");

  // Check if we are on the news-blog.html page and generate cards
  if (blogGrid) {
    generateBlogCards();
  }

  // Check if we are on the single-blog.html page and display the full article
  if (blogContent) {
    displaySingleBlog();
  }

  // Function to generate the HTML for all blog post cards
  function generateBlogCards() {
    let cardsHtml = "";
    // Loop through the blogPosts array defined in data.js
    blogPosts.forEach((post) => {
      cardsHtml += `
                <div class="col">
                    <div class="card h-100 shadow-sm card-hover">
                        <img src="${post.image}" class="card-img-top img-fluid" alt="${post.title}">
                        <div class="card-body d-flex flex-column">
                            <span class="badge bg-primary text-white mb-2">${post.category}</span>
                            <h5 class="card-title">${post.title}</h5>
                            <p class="card-text">${post.summary}</p>
                            <a href="single-blog.html?id=${post.id}" class="btn btn-primary mt-auto">Read More</a>
                        </div>
                    </div>
                </div>
            `;
    });
    blogGrid.innerHTML = cardsHtml;
  }

  // Function to display a single blog post
  function displaySingleBlog() {
    // Get the post ID from the URL query parameter
    const urlParams = new URLSearchParams(window.location.search);
    const postId = urlParams.get("id");
    // Find the corresponding post in the data array
    const post = blogPosts.find((p) => p.id == postId);

    if (post) {
      // Generate HTML for the single blog post
      let contentHtml = `
                <nav aria-label="breadcrumb" class="mb-4">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="news-blog.html">News Blog</a></li>
                        <li class="breadcrumb-item active" aria-current="page">${
                          post.title
                        }</li>
                    </ol>
                </nav>
                <article>
                    <h1 class="mb-3">${post.title}</h1>
                    <img src="${
                      post.image
                    }" class="img-fluid mb-4 rounded" alt="${post.title}">
                    <p class="lead">${post.summary}</p>
                    <p>${post.fullContent}</p>

                    <h2 class="mt-5">Key Takeaways</h2>
                    <ul>
                        ${post.keyTakeaways
                          .map((item) => `<li>${item}</li>`)
                          .join("")}
                    </ul>

                    <h2 class="mt-5">Related Links</h2>
                    <ol>
                        ${post.relatedLinks
                          .map((link) => `<li><a href="#">${link}</a></li>`)
                          .join("")}
                    </ol>
                </article>
            `;
      blogContent.innerHTML = contentHtml;
      document.title = `${post.title} - The Daily Byte`;
    } else {
      // Display an error message if the post is not found
      blogContent.innerHTML = `
                <div class="alert alert-danger" role="alert">
                    Article not found. Please go back to the <a href="news-blog.html">News Blog</a>.
                </div>
            `;
      document.title = "Article Not Found - The Daily Byte";
    }
  }

  // --- Contact Form Validation ---
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();

      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const message = document.getElementById("message").value.trim();

      if (name === "" || email === "" || message === "") {
        showModal("Error!", "Please fill out all required fields.", "error");
      } else {
        showModal(
          "Success!",
          "Thank you for your message! We will get back to you shortly.",
          "success"
        );
        contactForm.reset();
      }
    });
  }

  // --- Utility function to show modals (replaces alert()s) ---
  function showModal(title, body, type) {
    const modalEl = document.getElementById("alertModal");
    const modalTitle = modalEl.querySelector(".modal-title");
    const modalBody = modalEl.querySelector(".modal-body p");
    const modalHeader = modalEl.querySelector(".modal-header");

    modalTitle.textContent = title;
    modalBody.textContent = body;

    modalHeader.classList.remove("bg-success", "bg-danger", "text-white");
    modalTitle.classList.remove("text-success", "text-danger");

    if (type === "success") {
      modalHeader.classList.add("bg-success", "text-white");
    } else if (type === "error") {
      modalHeader.classList.add("bg-danger", "text-white");
    }

    const myModal = new bootstrap.Modal(modalEl);
    myModal.show();
  }
});
