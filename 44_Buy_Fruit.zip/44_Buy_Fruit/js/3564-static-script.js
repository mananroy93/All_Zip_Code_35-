document.addEventListener('DOMContentLoaded', function() {
    // --- Bootstrap Carousel Initialization for Hero Section ---
    const heroCarousel = document.getElementById('heroCarousel');
    if (heroCarousel) {
        new bootstrap.Carousel(heroCarousel, {
            interval: 4000, // Slow transition: 4000ms (4 seconds)
            pause: 'hover' // Pause on hover
        });
    }

    // --- Cart Functionality ---
    const cartItemsContainer = document.querySelector('.cart-items-container');
    const cartTotalPriceElement = document.querySelector('.cart-total-price');
    const cartItemCountElement = document.querySelector('.cart-item-count');
    const checkoutBtn = document.querySelector('.checkout-btn');
    const cartEmptyMessage = document.querySelector('.cart-empty-message');
    const selectedServiceInput = document.getElementById('selectedServiceInput');

    const CART_STORAGE_KEY = 'edenfyorpe_cart_items_' + generateUniqueId();

    // Helper to generate a unique ID for localStorage
    function generateUniqueId() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    // Load cart from localStorage
    function loadCart() {
        try {
            const storedCart = localStorage.getItem(CART_STORAGE_KEY);
            return storedCart ? JSON.parse(storedCart) : [];
        } catch (e) {
            console.error("Error loading cart from localStorage:", e);
            return [];
        }
    }

    // Save cart to localStorage
    function saveCart(cart) {
        try {
            localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
        } catch (e) {
            console.error("Error saving cart to localStorage:", e);
        }
    }

    let cart = loadCart();

    // Render cart items in the modal
    function renderCart() {
        if (!cartItemsContainer || !cartTotalPriceElement || !cartItemCountElement || !checkoutBtn || !cartEmptyMessage) {
            console.warn("Cart elements not found, cannot render cart.");
            return;
        }

        cartItemsContainer.innerHTML = '';
        let total = 0;
        let itemCount = 0;

        if (cart.length === 0) {
            cartEmptyMessage.style.display = 'block';
            checkoutBtn.disabled = true;
        } else {
            cartEmptyMessage.style.display = 'none';
            checkoutBtn.disabled = false;
            cart.forEach(item => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;
                itemCount += item.quantity;

                const cartItemDiv = document.createElement('div');
                cartItemDiv.classList.add('cart-item');
                cartItemDiv.dataset.productId = item.id;
                cartItemDiv.innerHTML = `
                    <img src="${item.image}" alt="${item.name}">
                    <div class="cart-item-details">
                        <h6>${item.name}</h6>
                        <p class="text-muted mb-1">$${item.price.toFixed(2)} each</p>
                    </div>
                    <div class="cart-item-controls">
                        <button class="btn btn-sm btn-outline-secondary decrease-quantity" data-id="${item.id}">-</button>
                        <input type="number" class="form-control form-control-sm item-quantity" value="${item.quantity}" min="1" data-id="${item.id}">
                        <button class="btn btn-sm btn-outline-secondary increase-quantity" data-id="${item.id}">+</button>
                    </div>
                    <div class="cart-item-subtotal">$${itemTotal.toFixed(2)}</div>
                    <button class="btn btn-sm btn-danger remove-item-btn ms-3" data-id="${item.id}"><i class="bi bi-trash"></i></button>
                `;
                cartItemsContainer.appendChild(cartItemDiv);
            });
        }

        cartTotalPriceElement.textContent = `$${total.toFixed(2)}`;
        cartItemCountElement.textContent = itemCount;

        // Update hidden input for checkout form
        if (selectedServiceInput) {
            selectedServiceInput.value = JSON.stringify(cart.map(item => ({ id: item.id, name: item.name, quantity: item.quantity, price: item.price })));
        }

        addCartEventListeners();
    }

    // Add event listeners for cart item controls (after rendering)
    function addCartEventListeners() {
        document.querySelectorAll('.remove-item-btn').forEach(button => {
            button.onclick = (e) => removeItem(e.currentTarget.dataset.id);
        });

        document.querySelectorAll('.increase-quantity').forEach(button => {
            button.onclick = (e) => changeQuantity(e.currentTarget.dataset.id, 1);
        });

        document.querySelectorAll('.decrease-quantity').forEach(button => {
            button.onclick = (e) => changeQuantity(e.currentTarget.dataset.id, -1);
        });

        document.querySelectorAll('.item-quantity').forEach(input => {
            input.onchange = (e) => updateQuantityFromInput(e.currentTarget.dataset.id, parseInt(e.currentTarget.value));
            input.onkeyup = (e) => updateQuantityFromInput(e.currentTarget.dataset.id, parseInt(e.currentTarget.value));
        });
    }

    // Add item to cart
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productCard = this.closest('.product-card');
            if (!productCard) return;

            const productId = productCard.dataset.productId;
            const productName = productCard.dataset.productName;
            const productPrice = parseFloat(productCard.dataset.productPrice);
            const productImage = productCard.dataset.productImage;

            const existingItem = cart.find(item => item.id === productId);

            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({
                    id: productId,
                    name: productName,
                    price: productPrice,
                    image: productImage,
                    quantity: 1
                });
            }
            saveCart(cart);
            renderCart();

            // Open cart modal automatically
            const cartModal = new bootstrap.Modal(document.getElementById('cartModal'));
            cartModal.show();
        });
    });

    // Remove item from cart
    function removeItem(id) {
        cart = cart.filter(item => item.id !== id);
        saveCart(cart);
        renderCart();
    }

    // Change item quantity
    function changeQuantity(id, delta) {
        const item = cart.find(item => item.id === id);
        if (item) {
            item.quantity = Math.max(1, item.quantity + delta); // Ensure quantity is at least 1
            saveCart(cart);
            renderCart();
        }
    }

    // Update quantity from input field
    function updateQuantityFromInput(id, newQuantity) {
        const item = cart.find(item => item.id === id);
        if (item) {
            if (isNaN(newQuantity) || newQuantity < 1) {
                newQuantity = 1; // Default to 1 if invalid
            }
            item.quantity = newQuantity;
            saveCart(cart);
            renderCart();
        }
    }

    // Clear cart after successful order
    function clearCart() {
        cart = [];
        saveCart(cart);
        renderCart();
    }

    // Initial render of the cart when page loads
    renderCart();

    // --- Form Validation (Contact Form and Checkout Form) ---
    const forms = document.querySelectorAll('.needs-validation');

    Array.from(forms).forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);

        // Real-time validation for inputs
        Array.from(form.elements).forEach(input => {
            if (input.tagName === 'INPUT' || input.tagName === 'TEXTAREA' || input.tagName === 'SELECT') {
                input.addEventListener('input', function() {
                    if (this.checkValidity()) {
                        this.classList.remove('is-invalid');
                        this.classList.add('is-valid');
                    } else {
                        this.classList.remove('is-valid');
                        this.classList.add('is-invalid');
                    }
                });
                // Also check on blur for immediate feedback
                input.addEventListener('blur', function() {
                    if (this.value.trim() !== '') { // Only validate if not empty
                        if (this.checkValidity()) {
                            this.classList.remove('is-invalid');
                            this.classList.add('is-valid');
                        } else {
                            this.classList.remove('is-valid');
                            this.classList.add('is-invalid');
                        }
                    } else {
                        this.classList.remove('is-valid');
                        this.classList.remove('is-invalid'); // Remove validation state if empty
                    }
                });
            }
        });
    });

    // --- Checkout Form Submission Handling ---
    const checkoutForm = document.getElementById('checkoutForm');
    const orderConfirmationModal = new bootstrap.Modal(document.getElementById('orderConfirmationModal'));
    const orderIdDisplay = document.getElementById('orderIdDisplay');

    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            event.stopPropagation();

            if (checkoutForm.checkValidity()) {
                // Simulate form submission success
                const orderId = 'EDF-' + Math.random().toString(36).substr(2, 9).toUpperCase();
                if (orderIdDisplay) {
                    orderIdDisplay.textContent = orderId;
                }

                // Close checkout modal and open confirmation modal
                const checkoutModalInstance = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
                if (checkoutModalInstance) {
                    checkoutModalInstance.hide();
                }
                orderConfirmationModal.show();

                clearCart(); // Clear cart after successful order
                checkoutForm.reset(); // Reset form fields
                checkoutForm.classList.remove('was-validated'); // Remove validation classes
                Array.from(checkoutForm.elements).forEach(input => {
                    input.classList.remove('is-valid', 'is-invalid');
                });

                // In a real scenario, you would send data via fetch/XMLHttpRequest here
                // For example:
                /*
                const formData = new FormData(checkoutForm);
                fetch(checkoutForm.action, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    // Handle success (e.g., show confirmation modal)
                    const orderId = data.orderId || 'N/A'; // Get order ID from response
                    if (orderIdDisplay) { orderIdDisplay.textContent = orderId; }
                    const checkoutModalInstance = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
                    if (checkoutModalInstance) { checkoutModalInstance.hide(); }
                    orderConfirmationModal.show();
                    clearCart();
                    checkoutForm.reset();
                    checkoutForm.classList.remove('was-validated');
                })
                .catch(error => {
                    console.error('Order submission error:', error);
                    // Handle error (e.g., show error message)
                    alert('There was an error processing your order. Please try again.');
                });
                */

            } else {
                checkoutForm.classList.add('was-validated');
            }
        });
    }

    // --- Handle modal transitions ---
    const cartModalElement = document.getElementById('cartModal');
    const checkoutModalElement = document.getElementById('checkoutModal');

    if (cartModalElement && checkoutModalElement) {
        cartModalElement.addEventListener('hidden.bs.modal', function () {
            // When cart modal closes, if checkout modal is open, do nothing
            // Otherwise, ensure cart is up to date (though it should be)
        });

        checkoutModalElement.addEventListener('show.bs.modal', function () {
            // When checkout modal opens, ensure cart modal is hidden
            const cartModalInstance = bootstrap.Modal.getInstance(cartModalElement);
            if (cartModalInstance) {
                cartModalInstance.hide();
            }
        });

        checkoutModalElement.addEventListener('hidden.bs.modal', function () {
            // When checkout modal closes, if order confirmation is not open, re-open cart modal if cart is not empty
            const orderConfirmationModalInstance = bootstrap.Modal.getInstance(document.getElementById('orderConfirmationModal'));
            if (!orderConfirmationModalInstance || !orderConfirmationModalInstance._isShown) { // Check if confirmation modal is NOT shown
                if (cart.length > 0) {
                    const cartModalInstance = bootstrap.Modal.getInstance(cartModalElement);
                    if (cartModalInstance) {
                        cartModalInstance.show();
                    }
                }
            }
        });

// Получаем DOM-элемент модалки
const orderConfirmationModalElement = document.getElementById('orderConfirmationModal');

// Вешаем событие скрытия
orderConfirmationModalElement.addEventListener('hidden.bs.modal', function () {
    // После подтверждения закрываем корзину и чек-аут
    const cartModalInstance = bootstrap.Modal.getInstance(cartModalElement);
    if (cartModalInstance) cartModalInstance.hide();

    const checkoutModalInstance = bootstrap.Modal.getInstance(checkoutModalElement);
    if (checkoutModalInstance) checkoutModalInstance.hide();
});

    }
});