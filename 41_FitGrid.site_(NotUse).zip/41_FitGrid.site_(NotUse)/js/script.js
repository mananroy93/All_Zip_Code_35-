// js/script.js

document.addEventListener("DOMContentLoaded", function () {
  // --- 1. SET CURRENT YEAR IN FOOTER ---
  const currentYearSpan = document.getElementById("currentYear");
  if (currentYearSpan) {
    currentYearSpan.textContent = new Date().getFullYear();
  }

  // --- 2. COOKIE CONSENT BANNER LOGIC ---
  const cookieBanner = document.getElementById("cookieConsentBanner");
  const acceptCookiesBtn = document.getElementById("acceptCookies");

  // Check if user has already accepted cookies
  if (!localStorage.getItem("cookieConsent")) {
    cookieBanner.classList.add("show");
  }

  // Event listener for the accept button
  if (acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener("click", function () {
      localStorage.setItem("cookieConsent", "accepted");
      cookieBanner.classList.remove("show");
    });
  }

  // --- 3. CONTACT FORM VALIDATION LOGIC ---
  const contactForm = document.getElementById("contactForm");

  if (contactForm) {
    // Get the Bootstrap Modal instances
    const successModal = new bootstrap.Modal(
      document.getElementById("successModal")
    );
    const errorModal = new bootstrap.Modal(
      document.getElementById("errorModal")
    );

    contactForm.addEventListener("submit", function (event) {
      // Prevent the default form submission
      event.preventDefault();

      // Get form fields
      const name = document.getElementById("contactName").value.trim();
      const email = document.getElementById("contactEmail").value.trim();
      const message = document.getElementById("contactMessage").value.trim();

      // Simple validation
      if (name === "" || email === "" || message === "") {
        // Show error pop-up
        errorModal.show();
      } else {
        // Show success pop-up
        successModal.show();
        // Optionally, reset the form after successful submission
        contactForm.reset();
      }
    });
  }
});
