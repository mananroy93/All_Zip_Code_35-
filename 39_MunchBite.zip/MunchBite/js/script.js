
// MunchBite scripts

// Dynamic year fallback (serverless hosting)
document.addEventListener('DOMContentLoaded', function() {
  const y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  // Form validation for contact page
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });

  // Open recipe modal via query string on recipe.html
  const params = new URLSearchParams(window.location.search);
  const recipeKey = params.get('recipe');
  if (recipeKey) {
    const modalEl = document.getElementById('modal_' + recipeKey);
    if (modalEl) {
      const m = new bootstrap.Modal(modalEl);
      m.show();
    }
  }
  // Open seniors modal if specified
  if (params.get('modal') === 'seniors') {
    const seniorsEl = document.getElementById('modal_seniors');
    if (seniorsEl) {
      const m = new bootstrap.Modal(seniorsEl);
      m.show();
    }
  }
});
